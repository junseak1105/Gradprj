package com.gradprj.jhk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JhkApplicationTests {

	@Test
	void contextLoads() {
	}

}
