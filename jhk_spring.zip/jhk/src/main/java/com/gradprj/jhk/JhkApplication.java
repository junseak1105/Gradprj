package com.gradprj.jhk;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JhkApplication {

	public static void main(String[] args) {
		SpringApplication.run(JhkApplication.class, args);
	}

}
